require("./style.css");
document.write(require("./content.js"));
